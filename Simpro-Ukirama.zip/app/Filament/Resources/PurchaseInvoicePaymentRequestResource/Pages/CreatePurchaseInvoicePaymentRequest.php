<?php

namespace App\Filament\Resources\PurchaseInvoicePaymentRequestResource\Pages;

use App\Filament\Resources\PurchaseInvoicePaymentRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePurchaseInvoicePaymentRequest extends CreateRecord
{
    protected static string $resource = PurchaseInvoicePaymentRequestResource::class;
}
